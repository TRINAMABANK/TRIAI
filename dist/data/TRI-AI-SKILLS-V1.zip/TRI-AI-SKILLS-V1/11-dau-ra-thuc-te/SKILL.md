# Skill Tạo đầu ra thực tế
Chuyển phân tích thành checklist, bảng, báo cáo, biểu mẫu, kế hoạch, ma trận trách nhiệm, risk list, dashboard spec hoặc prompt phù hợp mục tiêu.
