# Skill Knowledge Base
Tổ chức tài liệu thành kho kiến thức có cấu trúc: nguồn → phân loại → metadata → truy xuất → kiểm tra nguồn → cập nhật phiên bản.
