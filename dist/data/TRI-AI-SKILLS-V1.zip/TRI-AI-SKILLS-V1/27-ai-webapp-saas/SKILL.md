# Skill AI WebApp/SaaS
Thiết kế ứng dụng AI gồm frontend, backend, OpenAI API, database, file storage, authentication, Skill Library, Agent và logging.
Ưu tiên V1 nhỏ, chạy được, sau đó mở rộng.
