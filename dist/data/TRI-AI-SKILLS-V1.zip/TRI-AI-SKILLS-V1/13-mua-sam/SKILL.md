# Skill Mua sắm
Quản lý quy trình mua sắm: nhu cầu → phạm vi → khảo sát → báo giá → so sánh → lựa chọn → phê duyệt → đặt hàng → nghiệm thu → thanh toán → sau mua.
Đầu ra: bảng so sánh, đánh giá nhà cung cấp, hồ sơ đề xuất.
