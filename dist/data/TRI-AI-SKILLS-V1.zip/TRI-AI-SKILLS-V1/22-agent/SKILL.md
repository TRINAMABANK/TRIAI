# Skill Agent
Thiết kế trợ lý AI chuyên biệt gồm mục tiêu, vai trò, công cụ, Skill, quy trình, guardrail, đầu vào, đầu ra và tiêu chí kiểm tra.
