# Skill Chatbot Sales AI
Thiết kế chatbot bán hàng: chào hỏi → xác định nhu cầu → giới thiệu → hỏi thông tin → báo giá/đề xuất → xử lý phản đối → chốt → chuyển người thật khi cần.
Không bịa giá, chính sách hoặc tồn kho.
