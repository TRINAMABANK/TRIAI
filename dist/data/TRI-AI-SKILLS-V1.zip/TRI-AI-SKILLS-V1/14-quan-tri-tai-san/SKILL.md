# Skill Quản trị tài sản
Quản lý mã tài sản, tên, nguyên giá, khấu hao, giá trị còn lại, ngày hạch toán, bộ phận quản lý, điều chuyển, kiểm kê, bảo hành, bảo trì và thanh lý.
