# Skill Phân tích chi phí
Phân tích tổng tiền, tỷ trọng, biến động, báo giá, CAPEX/OPEX, chi phí bảo trì, đơn giá và cơ hội tối ưu.
Không tự bịa giá thị trường khi chưa có dữ liệu.
