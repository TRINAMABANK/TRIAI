# Quản lý hồ sơ & tài liệu (05-quan-ly-ho-so)

Skill chuyên môn độc lập cho Hệ sinh thái Trí AI.

- **Mã Skill**: `quan-ly-ho-so`
- **Lĩnh vực**: Hồ sơ & Soạn thảo
- **Phiên bản**: 1.0.0
- **Tương thích**: Trí AI WebApp v1, Antigravity, Open WebUI, Dify, LangChain.

## Hướng dẫn nạp vào WebApp
1. Vào mục **Kho Skill** hoặc **Cài đặt** trên WebApp Trí AI.
2. Bấm **'Nạp Skill'** hoặc kéo thả file ZIP này vào hệ thống.
3. Hệ thống sẽ tự động kích hoạt Agent `Quản lý hồ sơ & tài liệu` và tích hợp vào danh sách lệnh nhanh.
