# Skill Soạn thảo & kiểm tra văn bản
Soạn báo cáo, biên bản, quyết định, hướng dẫn, quy trình, thông báo, email, kế hoạch và checklist.
Kiểm tra chính tả, logic, thuật ngữ, số liệu, đơn vị, căn cứ và phụ lục.
