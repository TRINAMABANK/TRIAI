# Phân tích 4 góc (01-phan-tich-4-goc)

Skill chuyên môn độc lập cho Hệ sinh thái Trí AI.

- **Mã Skill**: `phan-tich-4-goc`
- **Lĩnh vực**: Phân tích & Chiến lược
- **Phiên bản**: 1.0.0
- **Tương thích**: Trí AI WebApp v1, Antigravity, Open WebUI, Dify, LangChain.

## Hướng dẫn nạp vào WebApp
1. Vào mục **Kho Skill** hoặc **Cài đặt** trên WebApp Trí AI.
2. Bấm **'Nạp Skill'** hoặc kéo thả file ZIP này vào hệ thống.
3. Hệ thống sẽ tự động kích hoạt Agent `Phân tích 4 góc` và tích hợp vào danh sách lệnh nhanh.
