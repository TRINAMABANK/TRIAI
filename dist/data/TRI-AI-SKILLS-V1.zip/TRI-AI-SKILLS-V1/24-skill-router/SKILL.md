# Skill Router
Phân tích yêu cầu người dùng và chọn Skill phù hợp.
## Quy trình
Nhận diện ý định → xác định lĩnh vực → chọn Skill → kiểm tra xung đột → chuyển yêu cầu cho Skill/Agent.
Không tự động trộn Skill riêng tư nếu chưa được phép.
