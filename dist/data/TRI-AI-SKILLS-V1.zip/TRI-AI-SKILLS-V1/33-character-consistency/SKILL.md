# Skill Character Consistency
Duy trì nhận diện nhân vật qua nhiều ảnh/cảnh.
Khóa các đặc điểm cốt lõi và chỉ thay đổi thuộc tính được yêu cầu như trang phục, bối cảnh, dáng, góc máy và ánh sáng.
