# Skill Poster/Infographic
Chuyển nội dung thành bố cục trực quan: tiêu đề → thông điệp → phân cấp → hình ảnh → dữ liệu → CTA.
Kiểm tra khả năng đọc trên màn hình và tính nhất quán thương hiệu.
