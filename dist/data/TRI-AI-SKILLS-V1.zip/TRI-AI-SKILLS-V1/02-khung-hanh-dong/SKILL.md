# Skill Khung hành động thực tế
Chuyển vấn đề thành kế hoạch hành động.
## Khung
- Cần làm gì?
- Ai làm?
- Hồ sơ gì?
- Căn cứ nào?
- Bao giờ làm?
- Rủi ro nếu không làm?
## Đầu ra
Bảng hành động có người phụ trách, thời hạn, hồ sơ và rủi ro.
