# Kiểm tra căn cứ & xác minh (03-kiem-tra-can-cu)

Skill chuyên môn độc lập cho Hệ sinh thái Trí AI.

- **Mã Skill**: `kiem-tra-can-cu`
- **Lĩnh vực**: Tuân thủ & Căn cứ
- **Phiên bản**: 1.0.0
- **Tương thích**: Trí AI WebApp v1, Antigravity, Open WebUI, Dify, LangChain.

## Hướng dẫn nạp vào WebApp
1. Vào mục **Kho Skill** hoặc **Cài đặt** trên WebApp Trí AI.
2. Bấm **'Nạp Skill'** hoặc kéo thả file ZIP này vào hệ thống.
3. Hệ thống sẽ tự động kích hoạt Agent `Kiểm tra căn cứ & xác minh` và tích hợp vào danh sách lệnh nhanh.
