# Skill Chẩn đoán sự cố
Phân tích sự cố theo: nguyên nhân khả dĩ → nguy hiểm → kiểm tra hiện trường → biện pháp tạm thời → sửa chữa → kiểm tra sau sửa chữa.
Ưu tiên an toàn, cô lập nguy hiểm và duy trì vận hành.
