# Quy trình chuẩn cho Thiết kế Poster/Infographic

1. Tiếp nhận yêu cầu người dùng.
2. Rà soát dữ liệu đầu vào theo tiêu chuẩn Thiết kế & Đồ họa.
3. Xử lý logic và đối chiếu căn cứ thực tế.
4. Xuất kết quả kèm khuyến nghị và bảng hành động.
