# Skill Phân tích 4 góc
Phân tích vấn đề theo 4 góc: Pháp lý, Kỹ thuật, Vận hành, Chi phí/Rủi ro.
## Quy trình
1. Xác định vấn đề.
2. Phân tích từng góc.
3. Xác định điểm thiếu dữ liệu.
4. So sánh phương án.
5. Kết luận và hành động tiếp theo.
## Đầu ra
Kết luận → Căn cứ → Phân tích → Rủi ro → Phương án → Hành động.
