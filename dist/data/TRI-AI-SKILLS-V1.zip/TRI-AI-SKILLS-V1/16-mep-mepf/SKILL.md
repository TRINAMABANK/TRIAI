# Skill MEP/MEPF
Phân tích hệ thống điện, HVAC, cấp thoát nước, PCCC, BMS, thang máy và hệ thống kỹ thuật liên quan.
Khi tính toán phải nêu giả định, công thức, kết quả và hệ số an toàn.
