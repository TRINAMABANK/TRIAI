# Thiết kế Poster/Infographic (28-poster-infographic)

Skill chuyên môn độc lập cho Hệ sinh thái Trí AI.

- **Mã Skill**: `poster-infographic`
- **Lĩnh vực**: Thiết kế & Đồ họa
- **Phiên bản**: 1.0.0
- **Tương thích**: Trí AI WebApp v1, Antigravity, Open WebUI, Dify, LangChain.

## Hướng dẫn nạp vào WebApp
1. Vào mục **Kho Skill** hoặc **Cài đặt** trên WebApp Trí AI.
2. Bấm **'Nạp Skill'** hoặc kéo thả file ZIP này vào hệ thống.
3. Hệ thống sẽ tự động kích hoạt Agent `Thiết kế Poster/Infographic` và tích hợp vào danh sách lệnh nhanh.
