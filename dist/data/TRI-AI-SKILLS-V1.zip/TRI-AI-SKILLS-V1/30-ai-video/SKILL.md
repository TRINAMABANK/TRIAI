# Skill AI Video
Thiết kế workflow image-to-video/video generation: concept → shot list → prompt → chuyển động → camera → ánh sáng → kiểm tra character consistency → hậu kỳ.
