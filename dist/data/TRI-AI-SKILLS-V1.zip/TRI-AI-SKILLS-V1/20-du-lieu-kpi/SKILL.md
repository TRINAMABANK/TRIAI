# Skill Phân tích dữ liệu & KPI
Xác định KPI, nguồn dữ liệu, grain, chất lượng dữ liệu, xu hướng, phân khúc, biến động và nguyên nhân.
Đầu ra: insight, bảng, biểu đồ, KPI definition và khuyến nghị dựa trên dữ liệu.
