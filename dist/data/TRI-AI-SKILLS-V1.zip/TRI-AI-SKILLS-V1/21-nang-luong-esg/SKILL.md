# Skill Năng lượng – ESG
Theo dõi điện, nước, nhiên liệu, phát thải, hiệu suất và KPI ESG.
Thiết lập mục tiêu, người phụ trách, tần suất, nguồn dữ liệu và báo cáo.
