# Skill Hồ sơ nghiệm thu
Kiểm tra hồ sơ pháp lý, thiết kế, thi công, vật liệu/thiết bị, nhật ký, biên bản, thử nghiệm, hoàn công, vận hành và bàn giao.
Đối chiếu thiết kế được duyệt ↔ thi công ↔ hiện trạng.
