# Skill Tham mưu lãnh đạo
Chuẩn bị thông tin để lãnh đạo ra quyết định.
## Đầu ra
Tóm tắt 1 trang → vấn đề → căn cứ → chi phí → rủi ro → phương án → đề xuất → câu hỏi lãnh đạo có thể hỏi.
