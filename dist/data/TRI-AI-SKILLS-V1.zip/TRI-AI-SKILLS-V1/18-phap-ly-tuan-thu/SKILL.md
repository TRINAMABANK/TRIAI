# Skill Pháp lý & tuân thủ
Xác định vấn đề pháp lý, văn bản áp dụng, hiệu lực, phạm vi, nghĩa vụ, hồ sơ chứng minh và rủi ro.
Phân biệt thông tin pháp lý với ý kiến tư vấn.
