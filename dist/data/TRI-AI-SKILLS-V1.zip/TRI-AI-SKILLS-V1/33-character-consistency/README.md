# Giữ nhất quán nhân vật (33-character-consistency)

Skill chuyên môn độc lập cho Hệ sinh thái Trí AI.

- **Mã Skill**: `character-consistency`
- **Lĩnh vực**: KOL & Hình ảnh AI
- **Phiên bản**: 1.0.0
- **Tương thích**: Trí AI WebApp v1, Antigravity, Open WebUI, Dify, LangChain.

## Hướng dẫn nạp vào WebApp
1. Vào mục **Kho Skill** hoặc **Cài đặt** trên WebApp Trí AI.
2. Bấm **'Nạp Skill'** hoặc kéo thả file ZIP này vào hệ thống.
3. Hệ thống sẽ tự động kích hoạt Agent `Giữ nhất quán nhân vật` và tích hợp vào danh sách lệnh nhanh.
