# Skill Vận hành tòa nhà
Quản lý vận hành MEP/MEPF, điện, HVAC, nước, thang máy, BMS, an ninh, bảo trì, sự cố, nhà thầu, năng lượng và hồ sơ vận hành.
