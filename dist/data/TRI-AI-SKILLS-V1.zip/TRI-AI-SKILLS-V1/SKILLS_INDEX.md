# HỆ THỐNG 33 BỘ SKILL ĐỘC QUYỀN TRÍ AI (V1.0.0)

| STT | Mã Thư Mục | Tên Skill | Phân Loại | Trạng Thái |
|---|---|---|---|---|
| 01 | `01-phan-tich-4-goc` | **Phân tích 4 góc** | Phân tích & Chiến lược | Sẵn sàng thương mại |
| 02 | `02-khung-hanh-dong` | **Khung hành động thực tế** | Quản trị công việc | Sẵn sàng thương mại |
| 03 | `03-kiem-tra-can-cu` | **Kiểm tra căn cứ & xác minh** | Tuân thủ & Căn cứ | Sẵn sàng thương mại |
| 04 | `04-chan-doan-su-co` | **Chẩn đoán sự cố** | Kỹ thuật & Sự cố | Sẵn sàng thương mại |
| 05 | `05-quan-ly-ho-so` | **Quản lý hồ sơ & tài liệu** | Hồ sơ & Soạn thảo | Sẵn sàng thương mại |
| 06 | `06-tham-muu-lanh-dao` | **Tham mưu lãnh đạo** | Tham mưu & Quyết sách | Sẵn sàng thương mại |
| 07 | `07-phan-tich-chi-phi` | **Phân tích chi phí** | Tài chính & Chi phí | Sẵn sàng thương mại |
| 08 | `08-quan-ly-cong-viec` | **Quản lý công việc** | Hiệu suất làm việc | Sẵn sàng thương mại |
| 09 | `09-soan-thao-qa` | **Soạn thảo & kiểm tra văn bản** | Hồ sơ & Soạn thảo | Sẵn sàng thương mại |
| 10 | `10-ai-workflow` | **AI Workflow** | Trí tuệ nhân tạo (AI) | Sẵn sàng thương mại |
| 11 | `11-dau-ra-thuc-te` | **Tạo đầu ra thực tế** | Tạo đầu ra thực tế | Sẵn sàng thương mại |
| 12 | `12-an-toan-gioi-han` | **An toàn & giới hạn AI** | An toàn & Giới hạn | Sẵn sàng thương mại |
| 13 | `13-mua-sam` | **Mua sắm** | Mua sắm & Đấu thầu | Sẵn sàng thương mại |
| 14 | `14-quan-tri-tai-san` | **Quản trị tài sản** | Quản trị tài sản | Sẵn sàng thương mại |
| 15 | `15-van-hanh-toa-nha` | **Vận hành tòa nhà** | Vận hành tòa nhà | Sẵn sàng thương mại |
| 16 | `16-mep-mepf` | **MEP/MEPF** | Kỹ thuật Cơ điện MEP | Sẵn sàng thương mại |
| 17 | `17-pccc` | **PCCC** | An toàn PCCC | Sẵn sàng thương mại |
| 18 | `18-phap-ly-tuan-thu` | **Pháp lý & tuân thủ** | Pháp lý & Hợp đồng | Sẵn sàng thương mại |
| 19 | `19-ho-so-nghiem-thu` | **Hồ sơ nghiệm thu** | Hồ sơ nghiệm thu | Sẵn sàng thương mại |
| 20 | `20-du-lieu-kpi` | **Phân tích dữ liệu & KPI** | Dữ liệu & KPI | Sẵn sàng thương mại |
| 21 | `21-nang-luong-esg` | **Năng lượng – ESG** | Năng lượng & ESG | Sẵn sàng thương mại |
| 22 | `22-agent` | **Agent** | Trí tuệ nhân tạo (AI) | Sẵn sàng thương mại |
| 23 | `23-knowledge-base` | **Knowledge Base** | Trí tuệ nhân tạo (AI) | Sẵn sàng thương mại |
| 24 | `24-skill-router` | **Skill Router** | Trí tuệ nhân tạo (AI) | Sẵn sàng thương mại |
| 25 | `25-skill-analyzer` | **Skill Analyzer** | Trí tuệ nhân tạo (AI) | Sẵn sàng thương mại |
| 26 | `26-chatbot-sales-ai` | **Chatbot Sales AI** | Bán hàng & CSKH | Sẵn sàng thương mại |
| 27 | `27-ai-webapp-saas` | **AI WebApp/SaaS** | Phần mềm & SaaS | Sẵn sàng thương mại |
| 28 | `28-poster-infographic` | **Thiết kế Poster/Infographic** | Thiết kế & Đồ họa | Sẵn sàng thương mại |
| 29 | `29-nam-a-bank-enews` | **Nam A Bank eNews** | Thiết kế & Đồ họa | Sẵn sàng thương mại |
| 30 | `30-ai-video` | **AI Video** | Sản xuất AI Video | Sẵn sàng thương mại |
| 31 | `31-kol-thoi-trang` | **KOL Thời Trang** | KOL & Hình ảnh AI | Sẵn sàng thương mại |
| 32 | `32-reference-image` | **Học ảnh tham chiếu** | KOL & Hình ảnh AI | Sẵn sàng thương mại |
| 33 | `33-character-consistency` | **Giữ nhất quán nhân vật** | KOL & Hình ảnh AI | Sẵn sàng thương mại |
