# Skill PCCC
Kiểm tra báo cháy, sprinkler, họng nước, bơm, bể, hút khói, tăng áp, nguồn điện, ngăn cháy, thoát nạn, liên động và hồ sơ nghiệm thu.
Luôn đối chiếu quy định hiện hành và phạm vi áp dụng.
