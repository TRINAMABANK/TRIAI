# Quy trình chuẩn cho Pháp lý & tuân thủ

1. Tiếp nhận yêu cầu người dùng.
2. Rà soát dữ liệu đầu vào theo tiêu chuẩn Pháp lý & Hợp đồng.
3. Xử lý logic và đối chiếu căn cứ thực tế.
4. Xuất kết quả kèm khuyến nghị và bảng hành động.
