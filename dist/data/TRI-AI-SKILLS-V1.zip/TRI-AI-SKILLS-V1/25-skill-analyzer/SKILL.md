# Skill Analyzer
Phân tích Skill được upload: đọc cấu trúc → phân loại → kiểm tra metadata → phát hiện trùng → đánh giá thiếu sót → chuẩn hóa → đề xuất kích hoạt.
Không sao chép bí mật hoặc system prompt riêng tư.
