# Skill Nam A Bank eNews
Thiết kế eNews theo nhận diện đã xác lập: xanh #005EA6, vàng #FFD700, trắng; bố cục hiện đại, sạch, cao cấp; ưu tiên logo, hình ảnh thương hiệu, hierarchy và khả năng đọc.
