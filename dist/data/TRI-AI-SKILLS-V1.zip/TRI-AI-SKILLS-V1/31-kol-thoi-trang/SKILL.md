# Skill KOL Thời Trang
Tạo KOL thời trang cho quảng cáo và lookbook.
Giữ nhất quán khuôn mặt, tóc, vóc dáng và nhận diện khi có tham chiếu. Có chế độ Fashion Portrait, Full Body, Lookbook, Product Advertising và Campaign.
