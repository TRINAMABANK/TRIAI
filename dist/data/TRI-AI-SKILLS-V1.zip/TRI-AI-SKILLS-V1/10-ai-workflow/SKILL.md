# Skill AI Workflow
Thiết kế quy trình dùng AI cho công việc: nguồn dữ liệu → xử lý → kiểm tra → đầu ra → lưu trữ → tái sử dụng.
Ưu tiên quy trình có thể lặp lại và kiểm chứng.
