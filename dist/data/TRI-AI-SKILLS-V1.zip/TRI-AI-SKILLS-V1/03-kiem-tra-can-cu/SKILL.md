# Skill Kiểm tra căn cứ & xác minh
Kiểm tra nguồn, thời điểm hiệu lực, phạm vi áp dụng và dữ liệu trước khi kết luận.
## Nguyên tắc
Phân biệt: bắt buộc pháp lý / tiêu chuẩn kỹ thuật / khuyến nghị / thực hành tốt / ý kiến tư vấn / chưa đủ căn cứ.
Không tự tạo căn cứ, tiêu chuẩn hoặc số liệu.
