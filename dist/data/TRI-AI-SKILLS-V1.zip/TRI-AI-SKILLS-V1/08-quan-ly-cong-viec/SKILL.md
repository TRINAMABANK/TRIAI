# Skill Quản lý công việc
Quản lý nhiệm vụ theo: việc, người phụ trách, hạn, trạng thái, hồ sơ, rủi ro, việc chờ.
Ưu tiên P1–P4 theo mức độ khẩn cấp, an toàn, pháp lý và ảnh hưởng vận hành.
