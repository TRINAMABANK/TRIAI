# Quy trình chuẩn cho An toàn & giới hạn AI

1. Tiếp nhận yêu cầu người dùng.
2. Rà soát dữ liệu đầu vào theo tiêu chuẩn An toàn & Giới hạn.
3. Xử lý logic và đối chiếu căn cứ thực tế.
4. Xuất kết quả kèm khuyến nghị và bảng hành động.
