# Skill Học ảnh tham chiếu
Phân tích ảnh để trích xuất đặc điểm có thể sử dụng làm tham chiếu: khuôn mặt, tóc, dáng, trang phục, ánh sáng, bố cục và phong cách.
Phân biệt đặc điểm nhận diện với yếu tố có thể thay đổi.
