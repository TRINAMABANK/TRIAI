# Skill Quản lý hồ sơ & tài liệu
Kiểm tra tính đầy đủ, phiên bản, chữ ký, ngày tháng, phụ lục, căn cứ và khả năng truy xuất.
Đầu ra: danh mục hồ sơ, hồ sơ thiếu, hồ sơ mâu thuẫn, hành động bổ sung.
