# Skill Router (24-skill-router)

Skill chuyên môn độc lập cho Hệ sinh thái Trí AI.

- **Mã Skill**: `skill-router`
- **Lĩnh vực**: Trí tuệ nhân tạo (AI)
- **Phiên bản**: 1.0.0
- **Tương thích**: Trí AI WebApp v1, Antigravity, Open WebUI, Dify, LangChain.

## Hướng dẫn nạp vào WebApp
1. Vào mục **Kho Skill** hoặc **Cài đặt** trên WebApp Trí AI.
2. Bấm **'Nạp Skill'** hoặc kéo thả file ZIP này vào hệ thống.
3. Hệ thống sẽ tự động kích hoạt Agent `Skill Router` và tích hợp vào danh sách lệnh nhanh.
